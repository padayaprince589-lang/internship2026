-- Create the database
CREATE DATABASE IF NOT EXISTS invoice_system;
USE invoice_system;

-- Table for storing invoice details
CREATE TABLE IF NOT EXISTS invoices (
    id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_number VARCHAR(50) NOT NULL,
    project_name VARCHAR(100),
    from_name VARCHAR(100),
    from_address TEXT,
    from_email VARCHAR(100),
    from_phone VARCHAR(50),
    to_name VARCHAR(100),
    to_address TEXT,
    issued_date DATE,
    due_date DATE,
    total_amount DECIMAL(10, 2),
    notes TEXT,
    payment_method TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table for storing invoice items (linked to invoices)
CREATE TABLE IF NOT EXISTS invoice_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_id INT,
    description VARCHAR(255),
    units DECIMAL(10, 2),
    price DECIMAL(10, 2),
    amount DECIMAL(10, 2),
    FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE
);
