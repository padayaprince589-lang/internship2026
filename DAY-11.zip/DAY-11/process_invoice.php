<?php
// Database Connection Configuration
$host = 'localhost';
$username = 'root';
$password = ''; // Default XAMPP password is empty
$dbname = 'invoice_system';

// Create connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 1. Collect Invoice Data
    $invoice_number = isset($_POST['invoice_number']) ? $_POST['invoice_number'] : '';
    $project_name = isset($_POST['project_name']) ? $_POST['project_name'] : '';
    $from_name = isset($_POST['from_name']) ? $_POST['from_name'] : '';
    $from_address = isset($_POST['from_address']) ? $_POST['from_address'] : '';
    $from_email = isset($_POST['from_email']) ? $_POST['from_email'] : ''; // Note: Not in HTML form explicitly but schema has it
    $from_phone = isset($_POST['from_phone']) ? $_POST['from_phone'] : ''; // Note: Not in HTML form explicitly but schema has it
    $to_name = isset($_POST['to_name']) ? $_POST['to_name'] : '';
    $to_address = isset($_POST['to_address']) ? $_POST['to_address'] : '';
    $issued_date = isset($_POST['issued_date']) ? $_POST['issued_date'] : '';
    $due_date = isset($_POST['due_date']) ? $_POST['due_date'] : '';
    $notes = isset($_POST['notes']) ? $_POST['notes'] : '';
    $payment_method = isset($_POST['payment_method']) ? $_POST['payment_method'] : '';

    // Calculate Total Amount from Items
    $total_amount = 0;
    if (isset($_POST['items']) && is_array($_POST['items'])) {
        foreach ($_POST['items'] as $item) {
            $units = floatval($item['units']);
            $price = floatval($item['price']);
            $total_amount += ($units * $price);
        }
    }

    // 2. Insert Invoice into `invoices` table
    $sql_invoice = "INSERT INTO invoices (invoice_number, project_name, from_name, from_address, from_email, from_phone, to_name, to_address, issued_date, due_date, total_amount, notes, payment_method) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = $conn->prepare($sql_invoice);
    if ($stmt) {
        $stmt->bind_param("ssssssssssdss", 
            $invoice_number, $project_name, $from_name, $from_address, $from_email, $from_phone, 
            $to_name, $to_address, $issued_date, $due_date, $total_amount, $notes, $payment_method
        );

        if ($stmt->execute()) {
            $invoice_id = $conn->insert_id;
            
            // 3. Insert Items into `invoice_items` table
            if (isset($_POST['items']) && is_array($_POST['items'])) {
                $sql_item = "INSERT INTO invoice_items (invoice_id, description, units, price, amount) VALUES (?, ?, ?, ?, ?)";
                $stmt_item = $conn->prepare($sql_item);
                
                foreach ($_POST['items'] as $item) {
                    $desc = $item['description'];
                    $units = floatval($item['units']);
                    $price = floatval($item['price']);
                    $amount = $units * $price;
                    
                    if (!empty($desc)) { // Only insert if description is provided
                        $stmt_item->bind_param("isddd", $invoice_id, $desc, $units, $price, $amount);
                        $stmt_item->execute();
                    }
                }
                $stmt_item->close();
            }

            echo "<div style='font-family: sans-serif; padding: 20px; background: #d1fae5; color: #065f46; border-radius: 8px; max-width: 600px; margin: 20px auto; text-align: center;'>
                    <h2>Success!</h2>
                    <p>Invoice #$invoice_number saved successfully.</p>
                    <p>Total Amount: $$total_amount</p>
                    <br>
                    <a href='invoice.html' style='text-decoration: none; background: #059669; color: white; padding: 10px 20px; border-radius: 6px;'>Create Another Invoice</a>
                  </div>";
        } else {
            echo "Error: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Error preparing statement: " . $conn->error;
    }
} else {
    echo "Using GET method? Please submit the form.";
}

$conn->close();
?>
